/**
 * Created by Haris on 5/11/2017.
 */
'use strict';
var app = angular.module('cartController', ['ngCookies']);
fyndIQApp.controller('cartController',
    function ($scope, $window, $cookieStore) {
    $scope.WriteCookie = function () {
        $cookieStore.put("Name", $scope.title);
    };
    $scope.ReadCookie = function () {
        $window.alert($cookieStore.get('Name'));
    };
    $scope.RemoveCookie = function () {
        $cookieStore.remove('Name');
    };
});