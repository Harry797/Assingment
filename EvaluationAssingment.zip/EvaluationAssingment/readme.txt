http://localhost:63342/EvaluationAssingment/app/fyndIQDetails.html


run application  and check on the given local host 